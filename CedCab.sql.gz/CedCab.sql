-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Feb 04, 2021 at 04:32 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `CedCab`
--

-- --------------------------------------------------------

--
-- Table structure for table `Location`
--

CREATE TABLE `Location` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `distance` varchar(255) NOT NULL,
  `isAvailable` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `Location`
--

INSERT INTO `Location` (`id`, `name`, `distance`, `isAvailable`) VALUES
(1, 'Charbagh', '210', 1),
(2, 'Basti', '150', 0);

-- --------------------------------------------------------

--
-- Table structure for table `Ride`
--

CREATE TABLE `Ride` (
  `rideId` int(255) NOT NULL,
  `rideDate` date NOT NULL DEFAULT current_timestamp(),
  `rideFrom` varchar(255) NOT NULL,
  `rideTo` varchar(255) NOT NULL,
  `totalDistance` varchar(255) NOT NULL,
  `luggage` varchar(255) NOT NULL,
  `cabType` varchar(255) NOT NULL,
  `totalFare` varchar(255) NOT NULL,
  `status` int(255) NOT NULL,
  `customerUSerId` int(11) NOT NULL,
  `userID` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `Ride`
--

INSERT INTO `Ride` (`rideId`, `rideDate`, `rideFrom`, `rideTo`, `totalDistance`, `luggage`, `cabType`, `totalFare`, `status`, `customerUSerId`, `userID`) VALUES
(1, '2021-01-07', 'Charbagh', 'IndiraNagar', '10', '12', 'royal', '455', 0, 1, ''),
(2, '2021-01-07', 'Charbagh', 'IndiraNagar', '10', '12', 'royal', '455', 0, 1, ''),
(3, '2021-01-07', 'Charbagh', 'IndiraNagar', '10', '12', 'royal', '455', 0, 1, ''),
(4, '2021-01-07', 'BBD', 'Gorakhpur', '20', '23', 'mini', '2455', 0, 1, ''),
(5, '2021-01-07', 'IndiraNagar', 'Barabanki', '40', '123', 'mini', '1015', 0, 1, ''),
(6, '2021-01-07', 'Charbagh', 'IndiraNagar', '10', '12', 'mini', '395', 0, 1, ''),
(8, '2021-01-07', 'IndiraNagar', 'BBD', '10', '12', 'mini', '525', 0, 1, ''),
(9, '2021-01-07', 'IndiraNagar', 'BBD', '10', '12', 'mini', '525', 0, 1, ''),
(10, '2021-01-07', 'Charbagh', 'Barabanki', '50', '44', 'mini', '1145', 0, 1, ''),
(11, '2021-01-07', 'Charbagh', 'IndiraNagar', '10', '23', 'mini', '495', 0, 1, ''),
(12, '2021-01-07', 'Charbagh', 'Barabanki', '50', '23', 'mini', '1145', 0, 1, ''),
(13, '2021-01-07', 'Charbagh', 'BBD', '20', '14', 'mini', '655', 0, 1, ''),
(14, '2021-01-07', 'Charbagh', 'BBD', '20', '12', 'mini', '655', 0, 1, ''),
(15, '2021-01-07', 'Charbagh', 'Gorakhpur', '50', '123', 'suv', '3460', 0, 1, ''),
(16, '2021-01-07', 'Basti', 'Charbagh', '90', '2', 'suv', '2453', 0, 1, ''),
(17, '2021-01-07', 'IndiraNagar', 'Charbagh', '10', '1', 'royal', '405', 0, 1, ''),
(18, '2021-01-07', 'Charbagh', 'BBD', '20', '5', 'mini', '605', 0, 1, ''),
(19, '2021-01-07', 'Charbagh', 'BBD', '20', '5', 'mini', '605', 0, 1, ''),
(20, '2021-01-07', 'IndiraNagar', 'Barabanki', '40', '23', 'royal', '1115', 0, 1, ''),
(21, '2021-01-07', 'Charbagh', 'BBD', '20', '255', 'mini', '755', 0, 1, ''),
(22, '2021-01-07', 'Charbagh', 'BBD', '20', '1', 'mini', '605', 0, 1, ''),
(23, '2021-01-07', 'Charbagh', 'BBD', '20', '12', 'mini', '655', 0, 1, ''),
(24, '2021-01-07', 'Charbagh', 'Barabanki', '50', '2', 'royal', '1105', 0, 1, ''),
(25, '2021-01-07', 'Charbagh', 'BBD', '20', '23', 'mini', '755', 0, 1, ''),
(26, '2021-01-07', 'Charbagh', 'Barabanki', '50', '32', 'royal', '1255', 0, 1, ''),
(27, '2021-01-07', 'Charbagh', 'Barabanki', '50', '32', 'mini', '1145', 0, 1, ''),
(28, '2021-01-07', 'Faizabad', 'Gorakhpur', '50', '45', 'mini', '1705', 0, 1, ''),
(29, '2021-01-07', 'Gorakhpur', 'BBD', '20', '1', 'mini', '2305', 0, 1, ''),
(30, '2021-01-07', 'Basti', 'Barabanki', '30', '3', 'suv', '1661', 0, 1, ''),
(31, '2021-01-07', 'Basti', 'Barabanki', '30', '3', 'suv', '1661', 0, 1, ''),
(32, '2021-01-07', 'IndiraNagar', 'Barabanki', '40', '3', 'mini', '865', 0, 1, ''),
(33, '2021-01-07', 'IndiraNagar', 'Barabanki', '40', '21', 'mini', '1015', 0, 1, 'singhsumit880@gmail.com'),
(34, '2021-01-07', 'IndiraNagar', 'Barabanki', '40', '21', 'royal', '1115', 0, 1, 'singhsumit880@gmail.com'),
(35, '2021-01-07', 'IndiraNagar', 'Barabanki', '40', '43', 'mini', '1015', 0, 1, 'singhsumit880@gmail.com'),
(36, '2021-01-07', 'Charbagh', 'IndiraNagar', '10', '54', 'mini', '495', 0, 1, 'singhsumit880@gmail.com'),
(37, '2021-01-07', 'Charbagh', 'BBD', '20', '43', 'royal', '835', 0, 1, 'singhsumit880@gmail.com'),
(38, '2021-01-07', 'IndiraNagar', 'Barabanki', '40', '12', 'mini', '915', 0, 1, 'singhsumit880@gmail.com'),
(39, '2021-01-08', 'BBD', 'Charbagh', '20', '21', 'royal', '835', 2, 1, 'singhsumit880@gmail.com'),
(40, '2021-01-08', 'IndiraNagar', 'Barabanki', '40', '21', 'mini', '1015', 0, 1, 'singhsumit880@gmail.com'),
(41, '2021-01-08', 'Charbagh', 'Barabanki', '50', '221', 'royal', '1255', 0, 1, 'singhsumit880@gmail.com'),
(42, '2021-01-08', 'Charbagh', 'IndiraNagar', '10', '21', 'royal', '555', 2, 1, 'singhsumit880@gmail.com'),
(43, '2021-01-08', 'Charbagh', 'IndiraNagar', '10', '44', 'mini', '495', 2, 1, 'singhsumit880@gmail.com'),
(44, '2021-01-08', 'Charbagh', 'BBD', '20', '21', 'mini', '755', 0, 1, 'singhsumit880@gmail.com'),
(45, '2021-01-08', 'Charbagh', 'IndiraNagar', '10', '21', 'mini', '495', 0, 1, 'singhsumit880@gmail.com'),
(46, '2021-01-08', 'Charbagh', 'BBD', '20', '43', 'mini', '755', 2, 1, 'singhsumit880@gmail.com'),
(47, '2021-01-08', 'Charbagh', 'BBD', '20', '1', 'mini', '605', 2, 1, 'singhsumit880@gmail.com'),
(48, '2021-01-08', 'Barabanki', 'BBD', '20', '54', 'mini', '755', 2, 1, 'singhsumit880@gmail.com'),
(49, '2021-01-08', 'Barabanki', 'BBD', '20', '21', 'royal', '835', 2, 1, 'singhsumit880@gmail.com'),
(50, '2021-01-08', 'IndiraNagar', 'Barabanki', '40', '21', 'royal', '1115', 2, 1, 'sheruk7898@gmail.com'),
(51, '2021-01-08', 'Charbagh', 'IndiraNagar', '10', '43', 'royal', '555', 1, 1, 'mouryasuneelsm.sm93@gmail.com'),
(52, '2021-01-08', 'Charbagh', 'IndiraNagar', '10', '21', 'mini', '495', 1, 1, 'singhsumit880@gmail.com'),
(53, '2021-01-08', 'Charbagh', 'IndiraNagar', '10', '21', 'mini', '495', 0, 1, 'singhsumit880@gmail.com'),
(54, '2021-01-08', 'BBD', 'IndiraNagar', '10', '21', 'mini', '625', 0, 1, 'singhsumit880@gmail.com'),
(55, '2021-01-08', 'IndiraNagar', 'BBD', '10', '1', 'royal', '545', 1, 1, 'singhsumit880@gmail.com'),
(56, '2021-01-08', 'Charbagh', 'IndiraNagar', '10', '3', 'royal', '405', 1, 1, 'singhsumit880@gmail.com'),
(57, '2021-01-08', 'Charbagh', 'IndiraNagar', '10', '1', 'mini', '345', 1, 1, 'singhsumit880@gmail.com'),
(58, '2021-01-08', 'IndiraNagar', 'Faizabad', '30', '213', 'royal', '1621', 1, 1, 'singhsumit880@gmail.com'),
(59, '2021-01-08', 'BBD', 'Faizabad', '10', '1', 'royal', '1227', 1, 1, 'singhsumit880@gmail.com'),
(60, '2021-01-08', 'IndiraNagar', 'Faizabad', '30', '21', 'royal', '1621', 1, 1, 'singhsumit880@gmail.com'),
(61, '2021-01-09', 'IndiraNagar', 'Gorakhpur', '40', '45', 'mini', '2645', 1, 1, 'singhsumit880@gmail.com'),
(62, '2021-01-09', 'Charbagh', 'Barabanki', '50', '32', 'mini', '1145', 1, 1, 'singhsumit880@gmail.com'),
(63, '2021-01-09', 'IndiraNagar', 'BBD', '10', '21', 'mini', '625', 1, 1, 'singhsumit880@gmail.com'),
(64, '2021-01-13', 'IndiraNagar', 'Barabanki', '40', '255', 'mini', '1015', 1, 1, 'singhsumit880@gmail.com'),
(65, '2021-01-18', 'BBD', 'IndiraNagar', '10', '23', 'mini', '625', 1, 1, 'singhsumit880@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `signup`
--

CREATE TABLE `signup` (
  `id` int(11) NOT NULL,
  `name` varchar(300) NOT NULL,
  `email` varchar(300) NOT NULL,
  `mobile` varchar(255) NOT NULL,
  `password` varchar(300) NOT NULL,
  `date` datetime NOT NULL DEFAULT current_timestamp(),
  `isadmin` tinyint(1) NOT NULL,
  `blockStatus` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `signup`
--

INSERT INTO `signup` (`id`, `name`, `email`, `mobile`, `password`, `date`, `isadmin`, `blockStatus`) VALUES
(1, 'sher', 'admin@gmail.com', '8577851005', 'Password123$', '2021-01-06 00:00:00', 1, 1),
(3, 'sumit', 'singhsumit880@gmail.com', '8577851005', '111', '2021-01-06 14:11:09', 0, 1),
(5, 'sher khan', 'sheruk7898@gmail.com', '8577851005', '123', '2021-01-06 17:57:21', 0, 1),
(7, 'Suneel', 'mouryasuneelsm.sm93@gmail.com', '8577851005', '123', '2021-01-08 15:05:27', 0, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Location`
--
ALTER TABLE `Location`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `Ride`
--
ALTER TABLE `Ride`
  ADD PRIMARY KEY (`rideId`),
  ADD KEY `customerUSerId` (`customerUSerId`);

--
-- Indexes for table `signup`
--
ALTER TABLE `signup`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Location`
--
ALTER TABLE `Location`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `Ride`
--
ALTER TABLE `Ride`
  MODIFY `rideId` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=66;

--
-- AUTO_INCREMENT for table `signup`
--
ALTER TABLE `signup`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `Ride`
--
ALTER TABLE `Ride`
  ADD CONSTRAINT `Ride_ibfk_1` FOREIGN KEY (`customerUSerId`) REFERENCES `signup` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
